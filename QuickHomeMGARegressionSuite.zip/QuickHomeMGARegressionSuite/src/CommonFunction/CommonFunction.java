package CommonFunction;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;

public class CommonFunction {
	public static WebDriver driver = null;
	protected static Properties properties = null;
	public static XSSFWorkbook output = new XSSFWorkbook();
	public static XSSFWorkbook ScheduleOfFormsWorkBook = new XSSFWorkbook();
	

	public Properties loadPropertyFile() throws IOException {
		FileInputStream fileInputStream = new FileInputStream("config.properties");
		properties = new Properties();
		properties.load(fileInputStream);
		return properties;
	}

	@BeforeSuite
	public void launchBrowser() throws IOException {
	     loadPropertyFile();
	     System.setProperty("webdriver.http.factory", "jdk-http-client");
		String browser = properties.getProperty("browser");
		String URL = properties.getProperty("url");
		String driverLoc = properties.getProperty("driverLocation");
		System.setProperty("webdriver.chrome.driver", driverLoc);

		ChromeOptions options = new ChromeOptions();

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);

		if (browser.equalsIgnoreCase("Chrome")) {

			System.setProperty("webdriver.chrome.driver", driverLoc);
			driver = new ChromeDriver();
		}
		/*
		 * else if(browser.equalsIgnoreCase("IE")) {
		 * 
		 * System.setProperty("webdriver.IE.driver", driverLoc); driver=new
		 * InternetExplorerDriver(); }
		 */

		driver.manage().window().maximize();
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

//	@AfterTest
	public void tearDown() throws IOException {
	//	 driver.quit();
	}
}
