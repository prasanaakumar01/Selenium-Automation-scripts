package CommonFunction;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class ReadDataFromExcel {
	@DataProvider(name="Datafromexcel")
    public static Object[][] readDatafromexcel() throws IOException {
        FileInputStream File = new FileInputStream(new File("D:\\Selenium Automation\\MGATestdata.xlsx"));
      
        //Create Workbook instance holding reference to .xlsx file
        XSSFWorkbook workbook = new XSSFWorkbook(File);

        //Get first/desired sheet from the workbook
        XSSFSheet Sheet = workbook.getSheetAt(0);
//        Workbook wrkBk = new XSSFWorkbook(fis);
//        Sheet sheet = wrkBk.getSheetAt(0);
        //fileIn.close();
        int rowCount = Sheet.getLastRowNum();//row count
        int coloumnCount = Sheet.getRow(0).getLastCellNum();//column count
        Object[][] objData = new Object[rowCount][1];//Object-> Where user can read the excel datas(Integer,String, etc)
        Map<Object, Object> mapData;
        for (int i = 0; i < rowCount; i++)
        {
            mapData = new HashMap<>();
            for (int j = 0; j < coloumnCount; j++)
            {
                DataFormatter dft = new DataFormatter();
                Cell keyCell =  Sheet.getRow(0).getCell(j);
                String tempKey = dft.formatCellValue(keyCell);
                Cell valueCell = Sheet.getRow(i + 1).getCell(j);
                String tempValue = dft.formatCellValue(valueCell);
                mapData.put(tempKey, tempValue);
            }
            objData[i][0] = mapData;
        }
        
        return objData;
    }

}
