package TestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import CommonFunction.CommonFunction;
import bsh.ParseException;
import io.netty.handler.timeout.TimeoutException;
import PageObjects.AgencyPageObject;
import PageObjects.LoginPageObject;
import CommonFunction.ReadDataFromExcel;
@Test
public class AgencyPageTest extends CommonFunction 
{
	@Test(dataProvider ="Datafromexcel",dataProviderClass = ReadDataFromExcel.class)
	

			
		public static void AgencySelection(Map map) throws InterruptedException, ParseException, InvocationTargetException, NoSuchElementException, TimeoutException
		{
			PageFactory.initElements(driver,AgencyPageObject.class);	
			 
		  AgencyPageObject.quoteNowLink.click();	
		  Thread.sleep(4000);
		  AgencyPageObject.enterAgencyOrAgent.sendKeys(map.get("Agency").toString());
		  Thread.sleep(4000);
		  Actions act4 = new Actions(driver);
		  act4.sendKeys(Keys.DOWN).perform();
			act4.sendKeys(Keys.ENTER).perform();
			Thread.sleep(4000);
		  //AgencyPageObject.selectAgent.click();
		  AgencyPageObject.continueToInsured.click();
	}
}
