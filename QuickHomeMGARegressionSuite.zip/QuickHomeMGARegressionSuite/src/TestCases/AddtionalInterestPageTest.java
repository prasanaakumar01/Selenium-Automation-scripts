package TestCases;

import org.testng.annotations.Test;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.google.protobuf.Duration;

import CommonFunction.CommonFunction;
import CommonFunction.ReadDataFromExcel;
import PageObjects.AdditionalInterestPageObject;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import bsh.ParseException;

@Test
public class AddtionalInterestPageTest extends CommonFunction
{
	public static void AdditionalInterest(Map map) throws InterruptedException, ParseException, InvocationTargetException
	{
		PageFactory.initElements(driver,AdditionalInterestPageObject.class);	
		
		Thread.sleep(5000);

		try
		{
			
			AdditionalInterestPageObject.ContinueTOAdditionalInterest.click();
			//AdditionalInterestPageObject.ContinueTOAdditionalInterest.click();
			
		}
		catch (StaleElementReferenceException eStale)
		{
			eStale.printStackTrace();
            throw(eStale);
		}
		}
		
	
}
