package TestCases;

import java.time.Duration;
import java.util.Map;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import CommonFunction.CommonFunction;
import PageObjects.LoginPageObject;
import TestCases.AgencyPageTest;
import CommonFunction.ReadDataFromExcel;

public class LoginPageTest extends CommonFunction
{
	@Test(dataProvider ="Datafromexcel",dataProviderClass = ReadDataFromExcel.class)
    public void runnerMethod(Map map) throws Exception
	{ 
	  loginPage(map);
	  TestCases.AgencyPageTest.AgencySelection(map);
	 TestCases.InsuredPageTest.Insureddetails(map);
	 TestCases.LocationPageTest.LocationDetails(map);
	 TestCases.AddtionalInterestPageTest.AdditionalInterest(map);
	 TestCases.CarrierSelectionPageTest.CarrierSelection(map);
	 TestCases.PolicyIssuePageTest.PolicyIssue(map);
 }
		
	public void loginPage(Map map) throws Exception
	{
		  PageFactory.initElements(driver, LoginPageObject.class);
	  LoginPageObject.userName.sendKeys(map.get("Username").toString());		
     LoginPageObject.password.clear();
     LoginPageObject.password.sendKeys(map.get("Password").toString());
	  LoginPageObject.signInBtn.click();
	//  Thread.sleep(10000);
	  
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	  
}
	}
