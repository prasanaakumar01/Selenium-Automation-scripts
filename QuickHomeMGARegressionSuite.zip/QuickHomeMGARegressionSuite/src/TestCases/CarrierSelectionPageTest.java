package TestCases;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.jsoup.select.Evaluator.Matches;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.google.protobuf.Value;

import CommonFunction.CommonFunction;
import CommonFunction.ReadDataFromExcel;
import PageObjects.CarrierSelectionPageObject;
import PageObjects.InsuredPageObject;
import bsh.ParseException;

public class CarrierSelectionPageTest extends CommonFunction {
	private static final CarrierSelectionPageObject ProductSelect = null;

	@Test(dataProvider = "Datafromexcel", dataProviderClass = ReadDataFromExcel.class)

	public static void CarrierSelection(Map map)
			throws InterruptedException, ParseException, InvocationTargetException {
		PageFactory.initElements(driver, CarrierSelectionPageObject.class);
		Thread.sleep(5000);

		CarrierSelectionPageObject.ContinueToCarrierSelection.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		CarrierSelectionPageObject.AddCarrierQuoteButton.click();
		Thread.sleep(5000);
		CarrierSelectionPageObject.CoverageTypeHomeownersDwelling.click();
		Thread.sleep(5000);
        //CarrierSelectionPageObject.SelectProducts.sendKeys(map.get("Products").toString());
        CarrierSelectionPageObject NNN= ProductSelect;
        String ProductSelect = map.get("Products").toString();
        System.out.print("Product selected is" +ProductSelect);
        
      //HO3 
      if(driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:0:Object__Policy__PolicyForm__Repeat1']")).getAttribute("value").matches(ProductSelect))
    		  
      {
    	  driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:0:Object__Policy__PolicyForm__Repeat1']")).click();	  
      }
      
      //HO5
      else if(driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:1:Object__Policy__PolicyForm__Repeat1']")).getAttribute("value").matches(ProductSelect)) 
      {
    	  driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:1:Object__Policy__PolicyForm__Repeat1']")).click();
	  }  
      
      //HO8
      else if(driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:2:Object__Policy__PolicyForm__Repeat1']")).getAttribute("value").matches(ProductSelect)) 
      {
    	  driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:2:Object__Policy__PolicyForm__Repeat1']")).click();
	  }  
      
      //DP1
      else if(driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:3:Object__Policy__PolicyForm__Repeat1']")).getAttribute("value").matches(ProductSelect)) 
      {
    	  driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:3:Object__Policy__PolicyForm__Repeat1']")).click();
	  }  
      
      //DP3
      else if(driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:4:Object__Policy__PolicyForm__Repeat1']")).getAttribute("value").matches(ProductSelect)) 
      {
    	  driver.findElement(By.xpath("//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:4:Object__Policy__PolicyForm__Repeat1']")).click();
	  }  
      
        



		CarrierSelectionPageObject.Carriername.sendKeys(map.get("Carrier Name").toString());
		Thread.sleep(5000);
		Actions act4 = new Actions(driver);
		act4.sendKeys(Keys.DOWN).perform();
		act4.sendKeys(Keys.ENTER).perform();
		Thread.sleep(5000);

		CarrierSelectionPageObject.CarrierQuoteNumber.sendKeys(map.get("Carrier Quote No").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 Thread.sleep(5000);
		CarrierSelectionPageObject.EnterPremium.sendKeys(map.get("Premium Amount").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.CoverageA.sendKeys(map.get("Cov A").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.CoverageB.sendKeys(map.get("Cov B").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.CoverageC.sendKeys(map.get("Cov C").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.CoverageD.sendKeys(map.get("Cov D").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);

		CarrierSelectionPageObject.PropertyPremium.sendKeys(map.get("Property Premium").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.OtherCoverageLimits.sendKeys(map.get("Other Cov Limits").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.LiabilityPersonalPremises.sendKeys(map.get("Personal Liability").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.MedicalPayments.sendKeys(map.get("Medical Payments").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.OtherLimits.sendKeys(map.get("Other Limits").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		CarrierSelectionPageObject.LiabilityPremium.sendKeys(map.get("Liability Premiums").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.AllOtherPeril.sendKeys(map.get("AOP").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.WindandHail.sendKeys(map.get("Wind&Hail").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(5000);

		CarrierSelectionPageObject.ClickLInkHere.click();
		Thread.sleep(5000);

		CarrierSelectionPageObject.PolicyFee.clear();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(3000);
		CarrierSelectionPageObject.PolicyFee.sendKeys(map.get("Policy Fee").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.InspectionFee.clear();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.InspectionFee.sendKeys(map.get("Inspection fee").toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(5000);
		CarrierSelectionPageObject.SaveCarrierQuote.click();
		Thread.sleep(15000);
	}
}
