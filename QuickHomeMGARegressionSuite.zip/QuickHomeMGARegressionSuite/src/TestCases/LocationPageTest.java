package TestCases;

import org.testng.annotations.Test;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import CommonFunction.CommonFunction;
import CommonFunction.ReadDataFromExcel;
import PageObjects.InsuredPageObject;
import PageObjects.LocationPageObject;
import org.openqa.selenium.support.ui.Select;
import bsh.ParseException;
import PageObjects.LocationPageObject;


public class LocationPageTest extends CommonFunction
{
	@Test(dataProvider ="Datafromexcel",dataProviderClass = ReadDataFromExcel.class)
	public static void LocationDetails(Map map) throws InterruptedException, ParseException, InvocationTargetException
	{
		PageFactory.initElements(driver,LocationPageObject .class);
		Thread.sleep(10000);
		LocationPageObject.MGALocationAddress.clear();
		Thread.sleep(5000);
		LocationPageObject.MGALocationAddress.sendKeys(map.get("Location Address").toString());
		Thread.sleep(5000);
		LocationPageObject.MGALocationAddress.click();
		Actions act4 = new Actions(driver);
		act4.sendKeys(Keys.DOWN).perform();
		act4.sendKeys(Keys.ENTER).perform();
		Thread.sleep(9000);
		
		
				
				//Occupancy Type
				Select occtyp = new Select(LocationPageObject.OccupancyType);
				occtyp.selectByVisibleText(String.valueOf(map.get("Occupany Type")));
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				//Construction Type 
				Select ConstructionType = new Select(LocationPageObject.ConstructionType);
				ConstructionType.selectByVisibleText(String.valueOf(map.get("Construction Type")));
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				LocationPageObject.YearBuilt.sendKeys(map.get("Year Built").toString());
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				LocationPageObject.LocationSaveButton.click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				
				
				
				

		
}
}
