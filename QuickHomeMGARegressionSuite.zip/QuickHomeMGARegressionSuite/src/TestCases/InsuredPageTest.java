package TestCases;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;

import CommonFunction.CommonFunction;
import CommonFunction.ReadDataFromExcel;
import PageObjects.InsuredPageObject;
import bsh.ParseException;
import PageObjects.InsuredPageObject;
import CommonFunction.RetryCls;


public class InsuredPageTest extends CommonFunction
{
	
	@Test(dataProvider ="Datafromexcel",dataProviderClass = ReadDataFromExcel.class)

	public static void Insureddetails(Map map) throws InterruptedException, ParseException, InvocationTargetException
	{
		PageFactory.initElements(driver,InsuredPageObject .class);
		RetryCls element = new RetryCls();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		InsuredPageObject.IsThisQuoteForTheMGAProductYes.click();
		Thread.sleep(3000);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		InsuredPageObject.InsuredFirstName.sendKeys(map.get("FirstName").toString());
		
		
		WebElement element1 = InsuredPageObject.InsuredLastName; 
		element1.click();
		element1.click();
		Thread.sleep(3000);
		element1.sendKeys(map.get("LastName").toString());
		Thread.sleep(4000);

		try
		{ 
			WebElement element15 = InsuredPageObject.DateOfBirth; 
			element15.click();
			element15.click();
			Thread.sleep(3000);
			element15.sendKeys(map.get("DateOfBirth").toString());
			Thread.sleep(3000);

		}
		catch (ElementNotInteractableException | NoSuchElementException e1)
		{
			e1.printStackTrace();
		}

//		
//		 RetryElements.Element_click(LocationPageObjects.heatingType);	
//			Thread.sleep(1000);
//			LocationPageObjects.heatingType.clear();
//			Thread.sleep(1000);
//			RetryElements.Element_sendKeys(LocationPageObjects.heatingType,String.valueOf(yrBuilt));
//			LocationPageObjects.plumbingType.clear();
//			Thread.sleep(1000);
//			RetryElements.Element_sendKeys(LocationPageObjects.plumbingType,String.valueOf(yrBuilt));
//			LocationPageObjects.waterHeater.clear();
//			Thread.sleep(1000);
		//WebElement element14 = InsuredPageObject.InsuredMailingAddress; 
		RetryCls.Element_click(InsuredPageObject.InsuredMailingAddress);	
        Thread.sleep(1000);
      //  RetryCls.Element_sendKeys.(map.get("Phonenumber").toString());
		//element14.click();
		//element14.sendKeys(map.get("InsuredMailingAddress").toString());
		Thread.sleep(5000);
		
		InsuredPageObject.InsuredMailingAddress.click();
		Thread.sleep(10000);
		Actions act4 = new Actions(driver);
		act4.sendKeys(Keys.DOWN).perform();
		act4.sendKeys(Keys.ENTER).perform();
		Thread.sleep(4000);



		WebElement element21 = InsuredPageObject.Phonenumber; 
		
		element21.sendKeys(map.get("Phonenumber").toString());

		WebElement element13 = InsuredPageObject.ContinueToLocation; 
		element13.click();
		Thread.sleep(8000);

		
}
}
