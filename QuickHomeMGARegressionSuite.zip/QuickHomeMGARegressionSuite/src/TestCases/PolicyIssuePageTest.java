package TestCases;

import java.lang.reflect.InvocationTargetException;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import CommonFunction.CommonFunction;
import CommonFunction.ReadDataFromExcel;
import PageObjects.PolicyIssuePageObject;
import bsh.ParseException;


public class PolicyIssuePageTest extends CommonFunction
{
	public static String PremiumfromXLSX;
	@Test(dataProvider ="Datafromexcel",dataProviderClass = ReadDataFromExcel.class)

	public static void PolicyIssue(Map map) throws InterruptedException, ParseException, InvocationTargetException
	{
		PageFactory.initElements(driver,PolicyIssuePageObject.class);	
		Thread.sleep(20000);
		PolicyIssuePageObject.QuoteLInk.click();
		Thread.sleep(10000);
		
		//Get Value for Quote Total Premiums
        WebElement CreatedQuote = driver.findElement(By.xpath("//*[@id='HeaderForm:quoteHeaderPanelTest:quoteNumberValue']/span"));
        //getText() to obtain text
        String s3= CreatedQuote.getText();
        System.out.println(" QuoteNumber is " + s3);
        Thread.sleep(5000);
        //SelectInspectionType = Inspection Type;
        
       PolicyIssuePageObject.TotalPremiumHover.click();
       Thread.sleep(4000);
        WebElement PremiumUI = driver.findElement(By.xpath("//*[@id='PremiumpanelDefaultQuote']/table/tbody/tr[1]/td[2]/label"));
        Thread.sleep(5000);
        //getText() to obtain text
        String UIDisplayingPremium= PremiumUI.getText();
      
        Thread.sleep(5000);
        
    //    PolicyIssuePageObject.sendKeys(map.get("Premium Amount").toString());
        PremiumfromXLSX = map.get("Premium Amount").toString();
        
        System.out.println("Base Premium From Testdata document  is" + PremiumfromXLSX + " Base Premium IN UI is " +UIDisplayingPremium);
        
       
        
        
        
//      Select SWR = new Select(PolicyIssuePageObject.SelectInspectionType);
//		SWR.selectByVisibleText(String.valueOf("Inspection Type"));
//		Thread.sleep(5000);
//-----------------------------------------------------------------------------------------------------------------

//        PolicyIssuePageObject.SelectInspectionType.click();
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//
//        //Thread.sleep(5000);
//        PolicyIssuePageObject.SelectInspectionType.sendKeys(map.get("Inspection Type").toString());
//        
//		
//		PolicyIssuePageObject.InspectionNotes.sendKeys(map.get("Inspection Instruction/Note").toString());
////		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
////		Thread.sleep(5000);
		
//		PolicyIssuePageObject.SaveInspectionDetails.click();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		Thread.sleep(10000);
//-------------------------------------------------------------------------------------------------------------------		
		PolicyIssuePageObject.BindRequestButton.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);
		PolicyIssuePageObject.IssuebinderHover.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(8000);
		PolicyIssuePageObject.IssuebinderClick.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Thread.sleep(5000);
	String Insuredname =PolicyIssuePageObject.InsurednameGet.getText();
	PolicyIssuePageObject.EnterPolicyNumber.sendKeys(map.get("Policy Number").toString());
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//Thread.sleep(4000);
	PolicyIssuePageObject.InsuredFirstName.sendKeys(Insuredname);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//Thread.sleep(4000);
	PolicyIssuePageObject.InsuredLastName.sendKeys(Insuredname);
	
	PolicyIssuePageObject.BinderpagenspectionType.sendKeys(map.get("Binder Page Inspection Type").toString());
	PolicyIssuePageObject.BinderpagenspectionNotes.sendKeys(map.get("Binder Page Inspection Notes").toString());
	PolicyIssuePageObject.Issuebinderfinal.click();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	Thread.sleep(5000);
	PolicyIssuePageObject.IssuePolicy.click();
	Thread.sleep(10000);
	
	
	driver.quit();
	driver = new ChromeDriver();
	driver.get("https://pluat.solartis.net/");
	//Thread.sleep(7000);
	driver.manage().window().maximize();
	//Thread.sleep(7000);
	
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        

}
}