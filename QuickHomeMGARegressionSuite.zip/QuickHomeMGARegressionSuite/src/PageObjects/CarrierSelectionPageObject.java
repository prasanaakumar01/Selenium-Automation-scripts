package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CarrierSelectionPageObject
{
	public static WebDriver driver=null;
	
	//ContinueToCarrierSelection
	@FindBy(xpath="//*[@id='AdditionalButton:ContinueToMgaCarrierSelection']") 
	public static WebElement ContinueToCarrierSelection;
	
	//QuoteType
	@FindBy(xpath="//select[@id='ProductSelectionFormPage:carrierTile:Object__PolicyDetail__QuoteType__DrpDown']") 
	public static WebElement QuoteType;
	
	//EnterRenewingPolicyNumber
	@FindBy(xpath="//input[@id='ProductSelectionFormPage:carrierTile:Object__QuoteAdditional__RenewalPolicyNumber_input']") 
	public static WebElement EnterRenewingPolicyNumber;
	
    //Rewrite
	@FindBy(xpath="//*[@id=\"ProductSelectionFormPage:carrierTile:Object__Quote__LapsePurpose\"]/tbody/tr/td[1]/label") 
	public static WebElement Rewrite;
	
	//Remarket
	@FindBy(xpath="//*[@id=\"ProductSelectionFormPage:carrierTile:Object__Quote__LapsePurpose\"]/tbody/tr/td[2]/label") 
	public static WebElement Remarket;
	
	//AddCarrierQuoteButton
	@FindBy(xpath="//*[@id='ProductSelectionFormPage:carrierTile:AddCarrierQuoteButton']") 
	public static WebElement AddCarrierQuoteButton;
	
	//CoverageTypeHomeownersDwelling
	@FindBy(xpath="//label[@for='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__Quote__HomeOwners']") 
	public static WebElement CoverageTypeHomeownersDwelling;
	
	//CarrierQuoteNumber
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__Carrier__CarrierQuoteNumber']") 
	public static WebElement CarrierQuoteNumber;
	
	//SelectProducts
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:j_idt5719']/tbody/tr/td[1]/label") 
	public static WebElement SelectProducts;
	
	//Ho3Form
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:0:Object__Policy__PolicyForm__Repeat1']") 
	public static WebElement Ho3Form;
	
	//Ho5Form
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:1:Object__Policy__PolicyForm__Repeat1']") 
	public static WebElement Ho5Form;
	
	//Ho8Form
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:2:Object__Policy__PolicyForm__Repeat1']") 
	public static WebElement Ho8Form;	
	
	//Dp1Form
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:3:Object__Policy__PolicyForm__Repeat1']") 
	public static WebElement Dp1Form;
	
	//Dp3Form
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:PFormsRepeat1:4:Object__Policy__PolicyForm__Repeat1']") 
	public static WebElement Dp3Form;
	
	//Carriername
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__CarrierName_input']") 
	public static WebElement Carriername;
	
	//AdmittedOrNOnAdmittedCarrier
	@FindBy(xpath="//*[@id=\"repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:typeupdatepanel\"]/label") 
	public static WebElement AdmittedOrNOnAdmittedCarrier;
	
	//CalendarIcon
	@FindBy(xpath="//*[@name='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:j_idt5763']") 
	public static WebElement CalendarIcon;
	
	//CalendarMonth
	@FindBy(xpath="//select[@class='ui-datepicker-month']") 
	public static WebElement CalendarMonth;
	
	//CalendarYear
	@FindBy(xpath="//select[@class='ui-datepicker-year']") 
	public static WebElement CalendarYear;
	
	//CalendarTodaysDate
	@FindBy(xpath="//*[@id=\"ui-datepicker-div\"]/div[2]/button[1]") 
	public static WebElement CalendarTodaysDate;
	//*Calendar
	
	//Carrier Quote Details
	//Entering Premium
	@FindBy(xpath="//input[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HOPremium__Display']") 
	public static WebElement EnterPremium;
	
	//Coverage A - (Dwelling)
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__DwellingLimit__Display']") 
	public static WebElement CoverageA;
	
	//Coverage B - (Other Structures)
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__StructureLimit__Display']") 
	public static WebElement CoverageB;
	
	//Coverage C - (Contents)
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__ContentsLimit__Display']") 
	public static WebElement CoverageC;
	
	//Coverage D - (Loss of Use / Rent)
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__LossOfUseLimit__Display']") 
	public static WebElement CoverageD;
	
	//Other Coverage limits
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__OtherCoverageLimit__Display']") 
	public static WebElement OtherCoverageLimits;
	
	//Property Premium
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__PropertyPremium__Display']") 
	public static WebElement PropertyPremium;
	
	//Liability - (Personal / Premises)
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__LiabilityLimit__Display']") 
	public static WebElement LiabilityPersonalPremises;
	
	//Medical Payments
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__MedicalPaymentLimit__Display']") 
	public static WebElement MedicalPayments;
	
	//Other Limits
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__OtherLiabilityLimit__Display']") 
	public static WebElement OtherLimits;
	
	//Liability Premium
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__LiabilityPremium__Display']") 
	public static WebElement LiabilityPremium;
	
	//All Other Perils
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__AOPDeductible__Display']") 
	public static WebElement AllOtherPeril;
	
	//Wind and Hail
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:Object__MGA__HomeOwners__WindHailCoverage__Display']") 
	public static WebElement WindandHail;
	
	
//click link here
	@FindBy(xpath="//a[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:MGA_TaxAndFeeForm:ClickHereToCalculate']") 
	public static WebElement ClickLInkHere;
	
	//Policy fee
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:MGA_TaxAndFeeForm:QFeelistIteration:0:j_idt6144']") 
	public static WebElement PolicyFee;
	
	
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:MGA_TaxAndFeeForm:QFeelistIteration:1:j_idt6144']") 
	public static WebElement InspectionFee;	
	
	
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:SaveCarrierQuote']/span") 
	public static WebElement SaveCarrierQuote;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	
	
	
	
}
