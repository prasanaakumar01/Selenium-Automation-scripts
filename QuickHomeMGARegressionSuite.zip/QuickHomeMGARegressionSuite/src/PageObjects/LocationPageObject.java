package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LocationPageObject
{
public static WebDriver driver=null;
	
	@FindBy(xpath="//input[@id='locations:MGALocationListTile:Object__Risk__ResProperty__BusinessAddress']") 
	public static WebElement MGALocationAddress;
	
	@FindBy(xpath="//*[@id=\"locations:MGALocationListTile:Object__Risk__ResProperty__TypeOfInsurance\"]/div[2]/span")
	public static WebElement Condominium;
	
	@FindBy(xpath="//select[@id='locations:MGALocationListTile:Object__Risk__ResProperty__occupancy2']")
	public static WebElement OccupancyType;
	
	@FindBy(xpath="//select[@id='locations:MGALocationListTile:Object__Risk__ResProperty__ConstructionType2']")
	public static WebElement ConstructionType;
	
	@FindBy(xpath="//input[@id='locations:MGALocationListTile:Object__Risk__ResProperty__DateBuilt']")
	public static WebElement YearBuilt;
	
	@FindBy(xpath="//*[@id=\"locations:MGALocationListTile:LocationSaveButton\"]/span")
	public static WebElement LocationSaveButton;
	
	
	
	
	
}
