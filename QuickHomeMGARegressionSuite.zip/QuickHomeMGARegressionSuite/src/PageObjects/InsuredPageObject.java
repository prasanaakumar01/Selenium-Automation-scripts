package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InsuredPageObject 
{
	public static WebDriver driver=null;
	
	 
	@FindBy(xpath="//*[@id=\"insuredTile:InsuredForm:Object__Customer__PreferredMarket\"]/div[1]/span") 
	public static WebElement IsThisQuoteForTheMGAProductYes;
	
	@FindBy(id="//select[@id='insuredTile:InsuredForm:Object__Customer__CompanyPerson']")
	public static WebElement SelectTheTypeOfInsured;	
	
	@FindBy(xpath="//*[@id=\"insuredTile:InsuredForm:Object__Customer__CompanyPerson\"]/option[1]")
	public static WebElement IndividualOption;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__CustomerLName_input']")
	public static WebElement InsuredLastName;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__CustomerFName_input']")
	public static WebElement InsuredFirstName;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__PrimaryDateOfBirth_Value']")
	public static WebElement DateOfBirth;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__SecondaryLastNameDisplay']")
	public static WebElement SecondaryLastName;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__SecondaryFirstNameDisplay']")
	public static WebElement SecondaryFirstName;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__BusinessAddress']")
	public static WebElement InsuredMailingAddress;
	
	@FindBy(xpath="//*[@id='ui-id-2]")
	public static WebElement SelectInsuredMailingAddress;
	
	
	@FindBy(xpath="//*[@id=\"insuredTile:InsuredForm:Object__Customer__RecentlyUsedAddress\"]/div[1]/span")
	public static WebElement HasTheMailingAddressBeenUsedByTheInsuredForAtleastSixMonthsYes;
	
	@FindBy(xpath="//*[@id=\"insuredTile:InsuredForm:Object__Customer__RecentlyUsedAddress\"]/div[2]/span")
	public static WebElement HasTheMailingAddressBeenUsedByTheInsuredForAtleastSixMonthsNo;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:PreviousAddress:Object__Customer__Prev__BusinessAddress']")
	public static WebElement PleaseEnterInsuredPreviousMailingAddress;
	
	@FindBy(xpath="//input[@id='insuredTile:InsuredForm:Object__Customer__Phone']")
	public static WebElement Phonenumber;
	
	@FindBy(xpath="//button[@id='insuredTile:InsuredSave']")
	public static WebElement ContinueToLocation;
	
	
	
	
	
	
	
	

	
	
	
	@FindBy(xpath="//*[@id=\"insuredTile:InsuredForm:Object__Customer__CompanyPerson\"]/option[2]")
	public static WebElement LLCLLPCorporationOption;
	
	@FindBy(xpath="//*[@id=\"insuredTile:InsuredForm:Object__Customer__CompanyPerson\"]/option[3]")
	public static WebElement TrustEstateOption;
	
	
	
}
