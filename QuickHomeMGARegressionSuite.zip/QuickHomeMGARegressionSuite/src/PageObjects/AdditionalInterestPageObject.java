package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdditionalInterestPageObject 
{
	public static WebDriver driver=null;
	
	//Click Additional Insured
	@FindBy(xpath="//*[@id='locations:MGAMLContinueToUWButton']") 
	public static WebElement ContinueTOAdditionalInterest;
	
	
}
