package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AgencyPageObject {
	public static WebDriver driver=null;
	
	//HomePage QuoteNow Link
	@FindBy(xpath="//*[@id='PlForms:j_idt549']/span") 
	public static WebElement quoteNowLink;
	
	//Enter the Agency Name
	@FindBy(id="AgencyForm:AgencyTile:Object__Agency__BusinessName_input")
	public static WebElement enterAgencyOrAgent;
	
	//Select the Agent
	@FindBy(xpath="//*[@id='AgencyForm:AgencyTile:Object__Agency__BusinessName_panel']/table/tbody/tr[1]/td/text()")
	public static WebElement selectAgent;
	
	//Click on Continue to Insured
	@FindBy(xpath="//*[@id=\"AgencyForm:AgencySave\"]/span")
	public static WebElement continueToInsured;
}
