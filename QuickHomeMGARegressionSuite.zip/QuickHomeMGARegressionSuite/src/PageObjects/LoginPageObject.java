package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPageObject {
	public static WebDriver driver=null;

	@FindBy(id="loginForm:login_username") 
	public static WebElement userName;
	@FindBy(id="loginForm:login_password") 
	public static WebElement password;
	@FindBy(name="loginForm:j_idt32") 
	public static WebElement signInBtn;
}
