package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PolicyIssuePageObject 
{
	public static WebDriver driver=null;
	
	 
	@FindBy(xpath="//*[@id='repeatedCarrier:0:CarrierQuoteForm:carrierQuoteTile:MGAHamburgerpanel']") 
	public static WebElement QuoteLInk;
	
	@FindBy(xpath="//*[@id=\"HeaderForm:quoteHeaderPanelTest:quoteNumberValue\"]/span") 
	public static WebElement GetQuoteNo;
	

	@FindBy(xpath="//*[@id=\"pltotalpremium\"]/span[2]") 
	public static WebElement TotalPremiumHover;
	
	
	
	@FindBy(xpath="//*[@id=\"PremiumpanelDefaultQuote\"]/table/tbody/tr[1]/td[2]/label") 
	public static WebElement BasePremiumUI;
	
	
	@FindBy(xpath="//select[@id='InspectionTile:inspecform:Object__Inspection__Type']") 
	public static WebElement SelectInspectionType;
	
	
	@FindBy(xpath="//*[@id='InspectionTile:inspecform:Object__Notes__Value']") 
	public static WebElement InspectionNotes;
	
	@FindBy(xpath="//*[@id=\"InspectionTile:inspecform:j_idt12186\"]/span") 
	public static WebElement SaveInspectionDetails;
	
	@FindBy(xpath="//button[@id='BindRequestButton']/span") 
	public static WebElement BindRequestButton;
	
	@FindBy(xpath="//img[@id='j_idt210']") 
	public static WebElement IssuebinderHover;
	
	@FindBy(xpath="//a[@id='IssueBinderLink_mga']") 
	public static WebElement IssuebinderClick;
	
	@FindBy(xpath="//input[@id='IssueBinderMGATile:binder:POLICY_NUMBER']") 
	public static WebElement EnterPolicyNumber;
	
	@FindBy(xpath="//div[@id='HeaderForm:quoteHeaderPanelTest:InsuredHeaderPanel']/label") 
	public static WebElement InsurednameGet;
	
	@FindBy(xpath="//input[@id='IssueBinderMGATile:binder:Object__QuoteInsured__ContactFName']") 
	public static WebElement InsuredFirstName;
	
	@FindBy(xpath="//input[@id='IssueBinderMGATile:binder:Object__QuoteInsured__ContactLName']") 
	public static WebElement InsuredLastName;
	
	@FindBy(xpath="//select[@id='IssueBinderMGATile:binder:Object__Inspection__Type']") 
	public static WebElement BinderpagenspectionType;
	
	@FindBy(xpath="//*[@id='IssueBinderMGATile:binder:Object__Notes__Value']") 
	public static WebElement BinderpagenspectionNotes;
	
	
	@FindBy(xpath="//*[@id='IssueBinderMGATile:binder:MgaIssueBinder']/span") 
	public static WebElement Issuebinderfinal;
	
	@FindBy(xpath="//*[@id=\"MGAIssuePolicyButton\"]/span") 
	public static WebElement IssuePolicy;
	
	@FindBy(xpath="//*[@id=\"HeaderForm:quoteHeaderPanelTest:quoteNumberValue\"]/span") 
	public static WebElement PolicyNUmberGet;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
